package svp.com.dontmissplaces.model.gps;

/**
 * Created by Pasha on 4/15/2016.
 */
public class Consts {
    /**
     * The state of the service is unknown
     */
    public static final int UNKNOWN = -1;

    /**
     * The service is actively logging, it has requested location update from the location provider.
     */
    public static final int LOGGING = 1;

    /**
     * The service is not active, but can be resumed to become active and store location changes as
     * part of a new segment of the current track.
     */
    public static final int PAUSED = 2;

    /**
     * The service is not active and can not resume a current track but must start a new one when becoming active.
     */
    public static final int STOPPED = 3;

    /**
     * The precision of the GPS provider is based on the custom time interval and distance.
     */
    public static final int LOGGING_CUSTOM = 0;

    /**
     * The GPS location provider is asked to update every 10 seconds or every 5 meters.
     */
    public static final int LOGGING_FINE   = 1;

    /**
     * The GPS location provider is asked to update every 15 seconds or every 10 meters.
     */
    public static final int LOGGING_NORMAL = 2;

    /**
     * The GPS location provider is asked to update every 30 seconds or every 25 meters.
     */
    public static final int LOGGING_COARSE = 3;

    /**
     * The radio location provider is asked to update every 5 minutes or every 500 meters.
     */
    public static final int LOGGING_GLOBAL = 4;

}
