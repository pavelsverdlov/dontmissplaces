package svp.com.dontmissplaces.model.gps;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import java.util.concurrent.Semaphore;

public class GPSLoggerServiceThread extends Thread
{
    private final ThreadListener listener;

    public interface ThreadListener {
        void handleMessage(Message msg);
    }

    private Handler mHandler;
    public Semaphore ready = new Semaphore(0);

    public GPSLoggerServiceThread(ThreadListener listener)
    {
        this.listener = listener;
        this.setName("GPSLoggerServiceThread");
    }

    @Override
    public void run()
    {
        Looper.prepare();
        mHandler = new Handler(){
            @Override
            public void handleMessage(Message msg)
            {
                _handleMessage(msg);
                //listener.handleMessage(msg);
            }
        };
        ready.release(); // Signal the looper and handler are created
        Looper.loop();
    }
    private void _handleMessage(Message s){}
}
