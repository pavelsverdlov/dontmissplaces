package svp.com.dontmissplaces.model.gps;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.GpsSatellite;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.Nullable;
import android.util.Log;

import java.util.Date;
import java.util.LinkedList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;
import java.util.concurrent.Semaphore;

import svp.com.dontmissplaces.R;
import svp.com.dontmissplaces.model.gps.streaming.StreamUtils;
import svp.com.dontmissplaces.model.gps.util.Constants;

/**
 * Created by Pasha on 4/15/2016.
 */
public class GPSService extends Service implements LocationListener {
    private final String TAG = "GPSService";
    /**
     * <code>mAcceptableAccuracy</code> indicates the maximum acceptable accuracy
     * of a waypoint in meters.
     */
    private float mMaxAcceptableAccuracy = 20;
    private int mSatellites = 0;
    /**
     * Should the GPS Status monitor update the notification bar
     */
    private boolean mStatusMonitor;

    /**
     * Listens to GPS status changes
     */
    private GpsStatus.Listener mStatusListener = new GpsStatus.Listener() {
        public synchronized void onGpsStatusChanged(int event) {
            switch (event) {
                case GpsStatus.GPS_EVENT_SATELLITE_STATUS:
                    if (mStatusMonitor) {
                        GpsStatus status = mLocationManager.getGpsStatus(null);
                        mSatellites = 0;
                        Iterable<GpsSatellite> list = status.getSatellites();
                        for (GpsSatellite satellite : list) {
                            if (satellite.usedInFix()) {
                                mSatellites++;
                            }
                        }
                        updateNotification();
                    }
                    break;
                case GpsStatus.GPS_EVENT_STOPPED:
                    break;
                case GpsStatus.GPS_EVENT_STARTED:
                    break;
                default:
                    break;
            }
        }
    };



    public GPSService(){

    }

    private Handler mHandler;

    public class GPSLoggerServiceThread extends Thread {
        public Semaphore ready = new Semaphore(0);
        public GPSLoggerServiceThread() {
            this.setName("GPSLoggerServiceThread");
        }
        @Override
        public void run() {
            Looper.prepare();
            mHandler = new Handler(){
                @Override
                public void handleMessage(Message msg){
                    _handleMessage(msg);
                }
            };
            ready.release(); // Signal the looper and handler are created
            Looper.loop();
        }
    }
    private void _handleMessage(Message s){}

    /**
     * Time thread to runs tasks that check whether the GPS listener has received
     * enough to consider the GPS system alive.
     */
    private Timer mHeartbeatTimer;

    /**
     * Task to determine if the GPS is alive
     */
    /*
    class Heartbeat extends TimerTask {

        private String mProvider;

        public Heartbeat(String provider) {
            mProvider = provider;
        }

        @Override
        public void run() {
            if (isLogging()) {
                // Collect the last location from the last logged location or a more recent from the last weak location
                Location checkLocation = mPreviousLocation;
                synchronized (mWeakLocations) {
                    if (!mWeakLocations.isEmpty()) {
                        if (checkLocation == null) {
                            checkLocation = mWeakLocations.lastElement();
                        } else {
                            Location weakLocation = mWeakLocations.lastElement();
                            checkLocation = weakLocation.getTime() > checkLocation.getTime() ? weakLocation : checkLocation;
                        }
                    }
                }
                // Is the last known GPS location something nearby we are not told?
                Location managerLocation = mLocationManager.getLastKnownLocation(mProvider);
                if (managerLocation != null && checkLocation != null) {
                    if (checkLocation.distanceTo(managerLocation) < 2 * mMaxAcceptableAccuracy) {
                        checkLocation = managerLocation.getTime() > checkLocation.getTime() ? managerLocation : checkLocation;
                    }
                }

                if (checkLocation == null || checkLocation.getTime() + mCheckPeriod < new Date().getTime()) {
                    Log.w(TAG, "GPS system failed to produce a location during logging: " + checkLocation);
                    mLoggingState = Consts.PAUSED;
                    resumeLogging();

                    if (mStatusMonitor) {
                        soundGpsSignalAlarm();
                    }

                }
            }
        }
    }*/

    Vector<Location> mWeakLocations;
    LinkedList<Double> mAltitudes;
    int mLoggingState;
    boolean mStartNextSegment;

    LocationManager mLocationManager;
    NotificationManager mNoticationManager;

    @Override
    public void onCreate() {
        super.onCreate();

        GPSLoggerServiceThread looper = new GPSLoggerServiceThread();
        looper.start();
        try{
            looper.ready.acquire();
        } catch (InterruptedException e) {
            Log.e(TAG, "Interrupted during wait for the GPSLoggerServiceThread to start, prepare for trouble!", e);
        }
        mHeartbeatTimer = new Timer("heartbeat", true);

        mWeakLocations = new Vector<Location>(3);
        mAltitudes = new LinkedList<Double>();
        mLoggingState = Consts.STOPPED;
        mStartNextSegment = false;
        mLocationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        mNoticationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);

        stopNotification();

        boolean startImmidiatly = true;
        crashRestoreState();
        if (startImmidiatly && mLoggingState == Consts.STOPPED)
        {
            startLogging();
//            ContentValues values = new ContentValues();
//            values.put(Tracks.NAME, "Recorded at startup");
//            getContentResolver().update(ContentUris.withAppendedId(Tracks.CONTENT_URI, mTrackId), values, null, null);
        } else {
            broadCastLoggingState();
        }
    }

    private void stopNotification() {
        if (Build.VERSION.SDK_INT >= 5) {
            //stopForegroundReflected(true);
        } else {
           // mNoticationManager.cancel(R.layout.map_google);
        }
    }
    private synchronized void crashRestoreState() {
        //SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        long previousState = Consts.LOGGING;//preferences.getInt(SERVICESTATE_STATE, Constants.STOPPED);
        if (previousState == Consts.LOGGING || previousState == Consts.PAUSED) {
            Log.w(TAG, "Recovering from a crash or kill and restoring state.");
            startNotification();
//            mTrackId = preferences.getLong(SERVICESTATE_TRACKID, -1);
//            mSegmentId = preferences.getLong(SERVICESTATE_SEGMENTID, -1);
//            mPrecision = preferences.getInt(SERVICESTATE_PRECISION, -1);
//            mDistance = preferences.getFloat(SERVICESTATE_DISTANCE, 0F);
            if (previousState == Consts.LOGGING) {
                mLoggingState = Consts.PAUSED;
                resumeLogging();
            } else if (previousState == Consts.PAUSED){
                mLoggingState = Consts.LOGGING;
                pauseLogging();
            }
        }
    }
    public synchronized void startLogging() {
        if (this.mLoggingState == Consts.STOPPED)
        {
            startNewTrack();
            sendRequestLocationUpdatesMessage();
            sendRequestStatusUpdateMessage();
            this.mLoggingState = Consts.LOGGING;
            updateWakeLock();
            startNotification();
            crashProtectState();
            broadCastLoggingState();
        }
    }
    public synchronized void pauseLogging(){
        if (this.mLoggingState == Consts.LOGGING)
        {
            mLocationManager.removeGpsStatusListener(mStatusListener);
            stopListening();
            mLoggingState = Consts.PAUSED;
            mPreviousLocation = null;
            updateWakeLock();
            updateNotification();
            mSatellites = 0;
            updateNotification();
            crashProtectState();
            broadCastLoggingState();
        }
    }
    public synchronized void resumeLogging(){
        if (this.mLoggingState == Consts.PAUSED)
        {
            if (mPrecision != Consts.LOGGING_GLOBAL)
            {
                mStartNextSegment = true;
            }
            sendRequestLocationUpdatesMessage();
            sendRequestStatusUpdateMessage();

            this.mLoggingState = Consts.LOGGING;
            updateWakeLock();
            updateNotification();
            crashProtectState();
            broadCastLoggingState();
        }
    }
    public synchronized void stopLogging(){
        mLoggingState = Consts.STOPPED;
        crashProtectState();

        updateWakeLock();

        //PreferenceManager.getDefaultSharedPreferences(this).unregisterOnSharedPreferenceChangeListener(this.mSharedPreferenceChangeListener);

        mLocationManager.removeGpsStatusListener(mStatusListener);
        stopListening();
        stopNotification();

        broadCastLoggingState();
    }
    /**
     * Send a system broadcast to notify a change in the logging or precision
     */
    private void broadCastLoggingState()
    {
        Intent broadcast = new Intent(Constants.LOGGING_STATE_CHANGED_ACTION);
        broadcast.putExtra(Constants.EXTRA_LOGGING_PRECISION, mPrecision);
        broadcast.putExtra(Constants.EXTRA_LOGGING_STATE, mLoggingState);
        this.getApplicationContext().sendBroadcast(broadcast);
        if( isLogging()){
            StreamUtils.initStreams(this);
        } else {
            StreamUtils.shutdownStreams(this);
        }
    }
    private void startNotification() {
//        mNoticationManager.cancel(R.layout.map_widgets);

        int icon = R.drawable.ic_maps_indicator_current_position;
        CharSequence tickerText = getResources().getString(R.string.service_start);
        long when = System.currentTimeMillis();

        mNotification = new Notification(icon, tickerText, when);
        mNotification.flags |= Notification.FLAG_ONGOING_EVENT;

        updateNotification();

        if (Build.VERSION.SDK_INT >= 5) {
            startForegroundReflected(R.layout.map_widgets, mNotification);
        } else {
            mNoticationManager.notify(R.layout.map_widgets, mNotification);
        }
    }



    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public void onLocationChanged(Location location) {

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
